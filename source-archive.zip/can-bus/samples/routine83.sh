./setconfig
./checkmode
./disablemask
./setspeed 196 255 135
./setnormal
./checkmode
./checkspeed
./monitor

./setconfig
./checkmode
./disablemask
./setspeed 197 250 135
./setnormal
./checkmode
./checkspeed
./monitor

./setconfig
./checkmode
./disablemask
./setspeed 199 248 132
./setnormal
./checkmode
./checkspeed
./monitor

./setconfig
./checkmode
./disablemask
./setspeed 201 232 131
./setnormal
./checkmode
./checkspeed
./monitor

./setconfig
./checkmode
./disablemask
./setspeed 139 224 130
./setnormal
./checkmode
./checkspeed
./monitor

./setconfig
./checkmode
./disablemask
./setspeed 142 208 130
./setnormal
./checkmode
./checkspeed
./monitor
